console.log('First Lambda Function');

exports.handler = function(event, context) {
	var result = {
		status: 200,
		message: 'First Lambda Function Respose'
	};
	context.succeed(result);
};
